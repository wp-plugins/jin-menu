=== JinMenu ===
Contributors: OpalWebTech
Donate link: http://buffernow.com/donate/
Tags: jquery code in menu, onclick in wp menu, javascript, wp menu, jQuery, onclick event
Requires at least: 3.4.1
Tested up to: 3.4
Stable tag: 1.0.0
The Jin Menu adds onclick event in wordpress custom menu,so that you can use your javascript/jQuery code from wordpress menu.

== Description ==

The Jin Menu adds onclick event in wordpress custom Menu, so that you can use your javascript/jQuery code from wordpress menu.

Features:

* Add Onclick In Wordpress Custom Menu.
* Add User Define javascript/jQuery Function To Theme Footer.
* Easy Interface.

For support and further information about the JinMenu plugin see the plugins homepage at [http://buffernow.com/jinmenu-faq/](http://buffernow.com/jinmenu-faq/ "Link to JinMenu faq").

== Installation ==

If you have ever installed a WordPress plugin, then installation will be pretty easy:

1. Download the JinMenu plugin archive and extract the files
1. Copy the resulting jinMenu directory into /wp-content/plugins/
1. Activate the plugin through the 'Plugins' menu of WordPress
1. Configure blog and user settings if needed

For support and further information about the JinMenu plugin see the plugins homepage at [http://buffernow.com/jinmenu](http://buffernow.com/jinmenu "Link to JinMenu Homepage").

== Frequently Asked Questions ==

= Where do I get support and further information =

For support and further information about the JinMenu plugin see the plugins homepage at [http://buffernow.com/jinmenu-faq/](http://buffernow.com/jinmenu-faq/ "Link to JinMenu faq").


== Changelog ==

= 1.0  =
* Requirements: WordPress 3.4.1 or higher
* Feature: Add Onclick In Wordpress Custom Menu.
* Feature: Add User Define javascript/jQuery Function To Theme Footer.
* Feature: Easy Interface.

== Upgrade Notice ==
this is first version of jin menu.