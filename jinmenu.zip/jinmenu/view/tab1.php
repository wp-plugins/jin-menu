	<table class="postbox widefat" cellspacing="0">
	<thead>
		<tr>
			<th colspan="2"></th>
		</tr>
	</thead>
	<tbody>		
		<tr class="alternate">
					<td>
						<blockquote>
	<p>Thanks for using JS on Menu plugin.<br> 
	Visit the <a href="http://buffernow.com/jinmenu" target="_blank">Plugin Homepage</a> here.
	<br>If your having problems, you can check the FAQ and get support from
	<a href="http://buffernow.com/jinmenu-faq/" target="_blank">Here</a>.<br> 
	</p>
<br>
<br>

	<div class="hint">
		<div id="nomnom_tweet">
	<b>Follow us on Twitter and Share on Facebook!</b><br><br>
		<p><a href="https://twitter.com/buffernow" class="twitter-follow-button">Follow @BufferNow</a>
		
		<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<div class="fb-like" data-href="http://www.facebook.com/computerdiary" data-send="false" data-width="450" data-show-faces="true"></div>
		
		<br>
	</div>
	</div>
	<p>Developer is <a href="mailto:opalwebtech@gmail.com">available for hire</p>
	</blockquote>
	
	</td>

<td  width="45%">
<br>
	<div id="headlines">
<font size="3">
<div class='rss-feed-admin'>
<!--<a href="http://buffernow.com/feed/" rel="alternate" type="application/rss+xml">
<img src="http://www.feedburner.com/fb/images/pub/feed-icon16x16.png" 
alt="" style="vertical-align:-15%;border:0"/></a>&nbsp;
<a href="http://feedburner.google.com/fb/a/mailverify?uri=ZeaksBlog" target="_blank" rel="alternate" type="application/rss+xml">
Latest Posts From Buffer Now</a>-->
<a href="http://buffernow.com/feed/" rel="alternate" type="application/rss+xml">
<img src="http://www.feedburner.com/fb/images/pub/feed-icon16x16.png" alt="" style="vertical-align:-15%;border:0"/>
</a>&nbsp;<a href="http://buffernow.com/">Latest Posts From Buffer Now</a>
</font><br><br>


	<?php
			//add RSS feed to options							
			$rss_options = array(
				'link' => 'http://buffernow.com',
				'url' => 'http://buffernow.com/feed/',
				'title' => 'BufferNow.com',
				'items' => 5,
				'show_summary' => 0,
				'show_author' => 0,
				'show_date' => 0,
				'before' => 'text'
			);
			wp_widget_rss_output( $rss_options ); ?>
			   
</div>
</div>
<br>
	<font size="3"><b>Support Our Team</b></font>
	<p>If you enjoy this plugin and want to support my time and effort, you can help us out by donating. Any amount big or small, all donations are appreciated.
<div id="paypal-float" style="margin-top:5px;width:300px;">
		
  <form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_blank">  
        <input type="hidden" name="cmd" value="_xclick">  
        <input type="hidden" name="business" value="rohitchowdhary75@gmail.com">  
        <input type="hidden" name="item_name" value="Donation">  
        <input type="hidden" name="item_number" value="1">  
   
        <input type="hidden" name="no_shipping" value="0">  
        <input type="hidden" name="no_note" value="1">  
        <input type="hidden" name="currency_code" value="USD">  
        <input type="hidden" name="lc" value="AU">  
        <input type="hidden" name="bn" value="PP-BuyNowBF"> 
	<center>
     $ <input type="text" style="width:50px;" name="amount" value="5"> 		
        <input type="image" border="0" style="height:22px;margin-bottom:-9px" alt="PayPal - The safer, easier way to pay online." name="submit" src="https://www.paypalobjects.com/en_US/i/btn/btn_donate_LG.gif">  
    </center>
    </form>  

</div>
</p>
		</td>				
		</tr>
	</tbody>
</table>